#!/usr/bin/env python

class MyDef(object):
    QUEUE_BLOCK_SIZE = 10000
    MAX_QUEUE_NAME = 50
    QUEUE_SIZE = 10240
