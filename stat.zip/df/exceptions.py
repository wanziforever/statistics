#!/usr/bin/env python

class NoSupportDataType(Exception):
    pass
