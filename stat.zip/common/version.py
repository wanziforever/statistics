# #!/usr/bin/env python

# from core.settings import settings

# def get_version():
#     '''if setting.VERSION is a number, setting.VERSION will be a integer,
#     but if the setting.VERSION is null, it will be a string, so just wrap it
#     to string in all case, it is configured to 0, just ignore it as null'''
#     if settings.VERSION == None:
#         return ""
#     version_str = str(settings.VERSION)
#     if version_str == "0":
#         version_str = ""
#     return version_str

