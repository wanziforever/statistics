#!/usr/bin/env python
# -*- coding: utf-8 -*-


def str2bool(s):
    if s.lower() == 'false':
        return False
    return bool(s)