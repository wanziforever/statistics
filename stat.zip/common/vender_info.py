#!/usr/bin/env python

vender_dict = {
    '1001':'SOHU',
    '1002':'IQIYI',
    '1003':'KU6',
    '1004':'CNTV',
    '1005':'LEKAN',
    '1006':'PPTV',
    '1007':'YOUKU',
    '1008':'VOOLE',
    '1009':'LETV',
    '1011':'TENCENT',
    '1012':'IFENG',
    '1013':'MANGGUO',
    '1014':'RAINBOW',
    '1021':'VTX'
    }
